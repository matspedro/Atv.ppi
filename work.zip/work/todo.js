
document.getElementById('addTaskButton').addEventListener('click', addTask);

//pega o texto da tarefa e a prioriedade
function addTask() {
    const taskText = document.getElementById('taskText').value;
    const priority = document.getElementById('priority').value;

    if (taskText === '') {
        alert('Por favor, insira uma tarefa.');
        return;
    }

    //seleciona a lista de tarefas
    const taskList = document.getElementById('taskList');
    
    //cria um elemento novo
    const taskItem = document.createElement('li');
    taskItem.classList.add('task-item', priority);

    // conteudo do item 
    taskItem.innerHTML = `
        <span>${taskText}</span>
        <div>
            <button class="complete-btn">✔</button>
            <button class="edit-btn">Editar</button>
            <button class="delete-btn">Apagar</button>
        </div>
    `;

    //insere o elemnto na lista
    taskList.appendChild(taskItem);

  

    document.getElementById('taskText').value = '';

    //muda pra concluido 
    taskItem.querySelector('.complete-btn').addEventListener('click', () => {
        taskItem.classList.toggle('completed');
    });


    taskItem.querySelector('.edit-btn').addEventListener('click', () => {
        const newTaskText = prompt('Editar tarefa:', taskText);
        if (newTaskText !== null) {
            taskItem.querySelector('span').textContent = newTaskText;
        }
    });

    taskItem.querySelector('.delete-btn').addEventListener('click', () => {
        taskList.removeChild(taskItem);
    });
}
